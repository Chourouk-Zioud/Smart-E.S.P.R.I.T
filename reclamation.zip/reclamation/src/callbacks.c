#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "rec.h"




char id[30],idrech[30];
GtkWidget *page_principale;
int m=0;
int a=0;
void
on_checkbuttonvm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
m=1;}
}


void
on_checkbuttonva_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
a=1;}
}


/*void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
page_principale=lookup_widget(button,"page_principale");
treeview1=lookup_widget(page_principale,"treeview1");
affichage(treeview1);
}*/


/*void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;
	    GtkWidget *treeview1;
	    page_principale=lookup_widget(button,"page_principale");
	    treeview1=lookup_widget(page_principale,"treeview1");
	
	    suppression(id,r);
            affichage(treeview1);


}*/


/*void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *windowskipo;

windowskipo=create_ajout_de_la_reclamation();
gtk_widget_show (windowskipo);
}*/


/*void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *windowskipoo;

windowskipoo=create_modification_de_la_reclamation();
gtk_widget_show (windowskipoo);
}*/


/*void
on_buttonboard_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *windowskipooo;

windowskipooo=create_statistique();
gtk_widget_show (windowskipooo);
}*/


/*void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];
char x[30];
char d[30];
char o[30];
char ll[30];
int lll;
GtkWidget *comboboxajout;
GtkWidget *entryid;
GtkWidget *entryprob;

GtkWidget *spinbuttonjj;
GtkWidget *spinbuttonmm;
GtkWidget *spinbuttonaa;

GtkWidget *spinbuttonjour;
GtkWidget *spinbuttonmois;
GtkWidget *spinbuttonanne;

GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *label49;

 

spinbuttonjour=lookup_widget(button, "spinbuttonjour");
spinbuttonmois=lookup_widget(button, "spinbuttonmois");
spinbuttonanne=lookup_widget(button, "spinbuttonanne");
spinbuttonjj=lookup_widget(button, "spinbuttonjj");
spinbuttonmm=lookup_widget(button, "spinbuttonmm");
spinbuttonaa=lookup_widget(button, "spinbuttonaa");

comboboxajout=lookup_widget(button, "comboboxajout");
entryid=lookup_widget(button,"entryid");
entryprob=lookup_widget(button,"entryprob");
entry1=lookup_widget(button,"entry1");
entry2=lookup_widget(button,"entry2");
label49=lookup_widget(button, "label49");

strcpy(ll,gtk_entry_get_text(GTK_ENTRY(entry2)));
lll=strlen(ll);
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entryprob)));
strcpy(x,gtk_entry_get_text(GTK_ENTRY(entryid)));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxajout)));
strcpy(o,Type);

if (veriff(x)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut ajouter une idee!");}

else if (veriff(x)==1){
	if(verifid(x)==0){gtk_label_set_text(GTK_LABEL(label49),"cette idee n est pas valable!");}
        else if (veriff(o)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut mentionner le service a reclamer!");}
        else if (lll!=8){gtk_label_set_text(GTK_LABEL(label49),"il faut entrer une vrai carte d identite !");}
        else if (veriff(d)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut mentionner le probleme!");}
        else if (a==0){gtk_label_set_text(GTK_LABEL(label49),"il faut valider le check button!");}
	else {
strcpy(r.identifiant,gtk_entry_get_text(GTK_ENTRY(entryid)));
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entryprob)));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(entry2)));

r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxajout)));
strcpy(r.type,Type);

ajout(r);
gtk_label_set_text(GTK_LABEL(label49),"Ajout effectué avec succès!");}}
a=0;}*/


/*void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];

char d[30];
char o[30];
char ll[30];
int lll;
GtkWidget *comboboxmodif;
GtkWidget *entrymodifid;
GtkWidget *entrymodifprob;
GtkWidget *spinbuttonmodifjj;
GtkWidget *spinbuttonmodifmm;
GtkWidget *spinbuttonmodifaa;

GtkWidget *spinbuttonmodifjour;
GtkWidget *spinbuttonmodifmois;
GtkWidget *spinbuttonmodifanne;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *label53;


    
	
spinbuttonmodifjour=lookup_widget(button, "spinbuttonmodifjour");
spinbuttonmodifmois=lookup_widget(button, "spinbuttonmodifmois");
spinbuttonmodifanne=lookup_widget(button, "spinbuttonmodifanne");
spinbuttonmodifjj=lookup_widget(button, "spinbuttonmodifjj");
spinbuttonmodifmm=lookup_widget(button, "spinbuttonmodifmm");
spinbuttonmodifaa=lookup_widget(button, "spinbuttonmodifaa");
comboboxmodif=lookup_widget(button, "comboboxmodif");
label53=lookup_widget(button, "label53");
entrymodifprob=lookup_widget(button,"entrymodifprob");
entry3=lookup_widget(button,"entry3");
entry4=lookup_widget(button,"entry4");
strcpy(ll,gtk_entry_get_text(GTK_ENTRY(entry4)));
lll=strlen(ll);
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entrymodifprob)));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmodif)));
strcpy(o,Type);


	
         if (veriff(o)==0){gtk_label_set_text(GTK_LABEL(label53),"il faut mentionner le service a reclamer!");}
        else if (lll!=8){gtk_label_set_text(GTK_LABEL(label53),"il faut entrer une vrai carte d identite !");}
        else if (veriff(d)==0){gtk_label_set_text(GTK_LABEL(label53),"il faut mentionner le probleme!");}
 	else if (m==0){gtk_label_set_text(GTK_LABEL(label53),"il faut valider le check button!");}      
else{
strcpy(r.identifiant,id);
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entrymodifprob)));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(entry4)));
r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmodif)));
strcpy(r.type,Type);


modification(id,r);
gtk_label_set_text(GTK_LABEL(label53),"modification effectué avec succès!");}
m=0;

}*/


/*void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char chr[30];char chh[30];
int k,h;
RECLAMATION r;
GtkWidget *labelrest;
GtkWidget *labelheb;
GtkWidget *labelstat;
k=nombrer(r);
h=nombreh(r);
labelrest=lookup_widget(button,"labelrest");
labelheb=lookup_widget(button,"labelheb");
labelstat=lookup_widget(button,"labelstat");
sprintf(chr,"%d",k);
sprintf(chh,"%d",h);
gtk_label_set_text(labelrest,chr);
gtk_label_set_text(labelheb,chh);
if (k>h)
{gtk_label_set_text(labelstat,"service Restauration");}
else 
{gtk_label_set_text(labelstat,"service Hébergement");}

}*/


/*void
on_buttonrecherche_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{


RECLAMATION r;
GtkWidget *entryrech;
GtkWidget *treeview1;
FILE*f;
FILE*f2;


page_principale=lookup_widget(button,"page_principale");
entryrech=lookup_widget(button,"entryrech");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(entryrech)));
f=fopen("reclamation.bin","rb");

 if(f!=NULL)
 {
  while(fread(&r,sizeof(RECLAMATION),1,f))
     {
       f2=fopen("recherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (strcmp(r.identifiant,idrech)==0)
     { 
     fwrite(&r,sizeof(RECLAMATION),1,f2);
     }
   
     treeview1=lookup_widget(page_principale,"treeview1");
     recherche(treeview1);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("recherche.bin");
}*/





/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(treeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}*/




void
on_buttonsupprimerhk_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;
	    GtkWidget *treeviewhk;
	    page_principale=lookup_widget(button,"page_principale");
	    treeview1=lookup_widget(page_principale,"treeviewhk");
	
	    suppression(id,r);
            affichage(treeviewhk);


}



void
on_buttonajouterhk_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *windowskipo;

windowskipo=create_ajout_de_la_reclamation();
gtk_widget_show (windowskipo);
}


void
on_buttonactualiserhk_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeviewhk;
page_principale=lookup_widget(button,"page_principale");
treeviewhk=lookup_widget(page_principale,"treeviewhk");
affichage(treeviewhk);
}


void
on_buttonmodifierhk_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowskipoo;

windowskipoo=create_modification_de_la_reclamation();
gtk_widget_show (windowskipoo);

}


void
on_buttonboardhk_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowskipooo;

windowskipooo=create_statistique();
gtk_widget_show (windowskipooo);

}


void
on_buttonrecherchehk_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;
GtkWidget *entryrech;
GtkWidget *treeviewhk;
FILE*f;
FILE*f2;


page_principale=lookup_widget(button,"page_principale");
entryrech=lookup_widget(button,"entryrech");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(entryrech)));
f=fopen("reclamation.bin","rb");

 if(f!=NULL)
 {
  while(fread(&r,sizeof(RECLAMATION),1,f))
     {
       f2=fopen("recherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (strcmp(r.identifiant,idrech)==0)
     { 
     fwrite(&r,sizeof(RECLAMATION),1,f2);
     }
   
     treeviewhk=lookup_widget(page_principale,"treeviewhk");
     recherche(treeviewhk);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("recherche.bin");

}


void
on_buttonajouthk_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];
char x[30];
char d[30];
char o[30];
char ll[30];
int lll;
GtkWidget *comboboxajout;
GtkWidget *entryid;
GtkWidget *entryprob;

GtkWidget *spinbuttonjj;
GtkWidget *spinbuttonmm;
GtkWidget *spinbuttonaa;

GtkWidget *spinbuttonjour;
GtkWidget *spinbuttonmois;
GtkWidget *spinbuttonanne;

GtkWidget *entry1;
GtkWidget *entry2;
GtkWidget *label49;

 

spinbuttonjour=lookup_widget(button, "spinbuttonjour");
spinbuttonmois=lookup_widget(button, "spinbuttonmois");
spinbuttonanne=lookup_widget(button, "spinbuttonanne");
spinbuttonjj=lookup_widget(button, "spinbuttonjj");
spinbuttonmm=lookup_widget(button, "spinbuttonmm");
spinbuttonaa=lookup_widget(button, "spinbuttonaa");

comboboxajout=lookup_widget(button, "comboboxajout");
entryid=lookup_widget(button,"entryid");
entryprob=lookup_widget(button,"entryprob");
entry1=lookup_widget(button,"entry1");
entry2=lookup_widget(button,"entry2");
label49=lookup_widget(button, "label49");

strcpy(ll,gtk_entry_get_text(GTK_ENTRY(entry2)));
lll=strlen(ll);
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entryprob)));
strcpy(x,gtk_entry_get_text(GTK_ENTRY(entryid)));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxajout)));
strcpy(o,Type);

if (veriff(x)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut ajouter une idee!");}

else if (veriff(x)==1){
	if(verifid(x)==0){gtk_label_set_text(GTK_LABEL(label49),"cette idee n est pas valable!");}
        else if (veriff(o)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut mentionner le service a reclamer!");}
        else if (lll!=8){gtk_label_set_text(GTK_LABEL(label49),"il faut entrer une vrai carte d identite !");}
        else if (veriff(d)==0){gtk_label_set_text(GTK_LABEL(label49),"il faut mentionner le probleme!");}
        else if (a==0){gtk_label_set_text(GTK_LABEL(label49),"il faut valider le check button!");}
	else {
strcpy(r.identifiant,gtk_entry_get_text(GTK_ENTRY(entryid)));
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entryprob)));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(entry2)));

r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxajout)));
strcpy(r.type,Type);

ajout(r);
gtk_label_set_text(GTK_LABEL(label49),"Ajout effectué avec succès!");}}
a=0;}


void
on_buttonmodifhk_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
RECLAMATION r;char Type[30];

char d[30];
char o[30];
char ll[30];
int lll;
GtkWidget *comboboxmodif;
GtkWidget *entrymodifid;
GtkWidget *entrymodifprob;
GtkWidget *spinbuttonmodifjj;
GtkWidget *spinbuttonmodifmm;
GtkWidget *spinbuttonmodifaa;

GtkWidget *spinbuttonmodifjour;
GtkWidget *spinbuttonmodifmois;
GtkWidget *spinbuttonmodifanne;
GtkWidget *entry3;
GtkWidget *entry4;
GtkWidget *label53;


    
	
spinbuttonmodifjour=lookup_widget(button, "spinbuttonmodifjour");
spinbuttonmodifmois=lookup_widget(button, "spinbuttonmodifmois");
spinbuttonmodifanne=lookup_widget(button, "spinbuttonmodifanne");
spinbuttonmodifjj=lookup_widget(button, "spinbuttonmodifjj");
spinbuttonmodifmm=lookup_widget(button, "spinbuttonmodifmm");
spinbuttonmodifaa=lookup_widget(button, "spinbuttonmodifaa");
comboboxmodif=lookup_widget(button, "comboboxmodif");
label53=lookup_widget(button, "label53");
entrymodifprob=lookup_widget(button,"entrymodifprob");
entry3=lookup_widget(button,"entry3");
entry4=lookup_widget(button,"entry4");
strcpy(ll,gtk_entry_get_text(GTK_ENTRY(entry4)));
lll=strlen(ll);
strcpy(d,gtk_entry_get_text(GTK_ENTRY(entrymodifprob)));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmodif)));
strcpy(o,Type);


	
         if (veriff(o)==0){gtk_label_set_text(GTK_LABEL(label53),"il faut mentionner le service a reclamer!");}
        else if (lll!=8){gtk_label_set_text(GTK_LABEL(label53),"il faut entrer une vrai carte d identite !");}
        else if (veriff(d)==0){gtk_label_set_text(GTK_LABEL(label53),"il faut mentionner le probleme!");}
 	else if (m==0){gtk_label_set_text(GTK_LABEL(label53),"il faut valider le check button!");}      
else{
strcpy(r.identifiant,id);
strcpy(r.problem,gtk_entry_get_text(GTK_ENTRY(entrymodifprob)));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(entry4)));
r.dater.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjour));
r.dater.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmois));
r.dater.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifanne));
r.datea.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifjj));
r.datea.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifmm));
r.datea.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonmodifaa));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxmodif)));
strcpy(r.type,Type);


modification(id,r);
gtk_label_set_text(GTK_LABEL(label53),"modification effectué avec succès!");}
m=0;

}


void
on_buttonafficherhk_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
char chr[30];char chh[30];
int k,h;
RECLAMATION r;
GtkWidget *labelrest;
GtkWidget *labelheb;
GtkWidget *labelstat;
k=nombrer(r);
h=nombreh(r);
labelrest=lookup_widget(button,"labelrest");
labelheb=lookup_widget(button,"labelheb");
labelstat=lookup_widget(button,"labelstat");
sprintf(chr,"%d",k);
sprintf(chh,"%d",h);
gtk_label_set_text(labelrest,chr);
gtk_label_set_text(labelheb,chh);
if (k>h)
{gtk_label_set_text(labelstat,"service Restauration");}
else 
{gtk_label_set_text(labelstat,"service Hébergement");}

}


void
on_treeviewhk_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(treeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}
