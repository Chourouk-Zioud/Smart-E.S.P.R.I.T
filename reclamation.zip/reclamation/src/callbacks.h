#include <gtk/gtk.h>


void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonboard_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbuttonvm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonva_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonsupprimerhk_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouterhk_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiserhk_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifierhk_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonboardhk_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrecherchehk_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouthk_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifhk_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficherhk_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewhk_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
