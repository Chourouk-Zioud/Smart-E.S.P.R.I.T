#include <gtk/gtk.h>


void
on_buttonAjout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomeajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestCapt_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_captDefect_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_alarmes_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonetagepannes_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_quit_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_togglebuttonfumee_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_togglebuttonmovsus_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_togglebuttonfuite_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonprotcivil_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconcierge_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonadministration_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_homelistealarm_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomeDEFECT_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_validermodification_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomemodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrechercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonhomeconsult_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitterconsult_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouterconsult_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifierconsult_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_afficher_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewconsult_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimercapteur_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_HOME_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
