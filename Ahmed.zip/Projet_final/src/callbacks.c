#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"


void
on_buttonAjout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
capt c;
GtkWidget * c_ref;
GtkWidget * c_val;
GtkWidget * c_type;
GtkWidget * c_etage;
GtkWidget * c_jour;
GtkWidget * c_heure;
GtkWidget *labelType;
GtkWidget *labelRef;
GtkWidget *labelEtage;
GtkWidget *labelValeur;
GtkWidget *labelJour;
GtkWidget *labelHeure;
GtkWidget *existe;
GtkWidget *success;
int b=1;

c_ref=lookup_widget(button, "entryRef");
c_val=lookup_widget(button, "entryVal");
c_type=lookup_widget(button, "comboboxTypeCapt");
c_etage=lookup_widget(button, "entryetage");
c_jour=lookup_widget(button, "entryjour");
c_heure=lookup_widget(button, "entryheure");

labelRef=lookup_widget(button,"label36");
labelValeur=lookup_widget(button,"label37");
labelType=lookup_widget(button,"label38");
labelEtage=lookup_widget(button,"label39");
labelJour=lookup_widget(button,"label40");
labelHeure=lookup_widget(button,"label41");
existe=lookup_widget(button,"label34");
success=lookup_widget(button,"label35");

strcpy(c.reference,gtk_entry_get_text(GTK_ENTRY(c_ref)));
strcpy(c.etage,gtk_entry_get_text(GTK_ENTRY(c_etage)));
strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(c_type)));
strcpy(c.valeur,gtk_entry_get_text(GTK_ENTRY(c_val)));
strcpy(c.jour,gtk_entry_get_text(GTK_ENTRY(c_jour)));
strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(c_heure)));

 gtk_widget_hide (success);
// controle saisie
if(strcmp(c.type,"")==0){
		  gtk_widget_show (labelType);
b=0;
}
else {
		  gtk_widget_hide(labelType);
}

if(strcmp(c.reference,"")==0){
		  gtk_widget_show (labelRef);
b=0;
}
else {
		  gtk_widget_hide(labelRef);
}
if(strcmp(c.etage,"")==0){
		  gtk_widget_show (labelEtage);
b=0;
}
else {
		  gtk_widget_hide(labelEtage);
}
if(strcmp(c.valeur,"")==0){
		  gtk_widget_show (labelValeur);
b=0;
}
else {
		  gtk_widget_hide(labelValeur);
}
if(strcmp(c.jour,"")==0){
		  gtk_widget_show (labelJour);
b=0;
}
else {
		  gtk_widget_hide(labelJour);
}
if(strcmp(c.heure,"")==0){
		  gtk_widget_show (labelHeure);
b=0;
}
else {
		  gtk_widget_hide(labelHeure);
}


if(b==1){

       if(exist_capteur(c.reference)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajoutercapteur(c);

						  gtk_widget_show (success);
        }

}
}


void
on_buttonhomeajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * home;
	home = create_menuPrinahmed ();
    gtk_widget_show (home);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "ajtCapt");
    gtk_widget_destroy(captHome);
}


void
on_gestCapt_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *menu;
	GtkWidget *gerer;
	int i;

	menu=lookup_widget(button,"menuPrinahmed");
	gtk_widget_destroy(menu);
	gerer=lookup_widget(button,"gestCapt");
	gerer = create_gestCapt ();

	gtk_widget_show(gerer);
}


void
on_captDefect_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	capt c;	
	GtkWidget * Cap_def;
	GtkWidget * treeview4;
	Cap_def=lookup_widget(button,"captDefect");
	Cap_def=create_captDefect();
	gtk_widget_show(Cap_def);
	Capteurs_Defect(c);
	treeview4=lookup_widget(Cap_def,"treeview6");
	thetreeview(treeview4,"capteur2.txt");
}


void
on_alarmes_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	capt c;
	GtkWidget * Listealarmes;
	GtkWidget * treeview;
	Listealarmes=lookup_widget(button,"alarmes");
	Listealarmes=create_listeAlarmes();
	gtk_widget_show(Listealarmes);
	Liste_Alarmes(c);
	treeview=lookup_widget(Listealarmes,"treeview2");
	thetreeview(treeview,"capteur1.txt");
}


void
on_buttonetagepannes_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_quit_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * home;
	home = create_menuPrinahmed ();
    gtk_widget_show (home);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "gestCapt");
    gtk_widget_destroy(captHome);
}




void
on_homelistealarm_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget * home;
	home = create_menuPrinahmed ();
	gtk_widget_show (home);
	GtkWidget *captHome;
	captHome = lookup_widget(button, "listeAlarmes");
	gtk_widget_destroy(captHome);
}


void
on_buttonhomeDEFECT_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget * home;
	home = create_menuPrinahmed ();
	gtk_widget_show (home);
	GtkWidget *captHome;
	captHome = lookup_widget(button, "captDefect");
	gtk_widget_destroy(captHome);
}


void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
	capt p;
	GtkWidget *reference,*type,*etage,*valeur,*jour, *heure, *annee, *fonction,*jour1, *mois1, *annee1 ;
	char ver[30];
	GtkWidget *labelType;
	GtkWidget *labelRef;
	GtkWidget *labelEtage;
	GtkWidget *labelValeur;
	GtkWidget *labelJour;
	GtkWidget *labelHeure;
	GtkWidget *existe;
	GtkWidget *success;
int b=1;

	
	reference=lookup_widget(button,"refm");
	type=lookup_widget(button,"comboboxm");
	etage=lookup_widget(button,"etagem");
	valeur=lookup_widget(button, "valm");
	jour=lookup_widget(button, "jourm");
	heure=lookup_widget(button, "heurem");

	labelRef=lookup_widget(button,"label66");
	labelValeur=lookup_widget(button,"label67");
	labelType=lookup_widget(button,"label68");
	labelEtage=lookup_widget(button,"label69");
	labelJour=lookup_widget(button,"label70");
	labelHeure=lookup_widget(button,"label71");
//////////////////////////////////
	existe=lookup_widget(button,"label73");
	success=lookup_widget(button,"label72");
////////////////////////////////////	
	strcpy(ver,gtk_entry_get_text(GTK_ENTRY(reference)));
	

	
	strcpy(p.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
	strcpy(p.etage,gtk_entry_get_text(GTK_ENTRY(etage)));
	strcpy(p.valeur,gtk_entry_get_text(GTK_ENTRY(valeur)));
	strcpy(p.jour,gtk_entry_get_text(GTK_ENTRY(jour)));
	strcpy(p.heure,gtk_entry_get_text(GTK_ENTRY(heure)));

	strcpy(p.reference,gtk_entry_get_text(GTK_ENTRY(reference)));
gtk_widget_hide (success);
	
// controle saisie
if(strcmp(p.type,"")==0){
		  gtk_widget_show (labelType);
b=0;
}
else {
		  gtk_widget_hide(labelType);
}

if(strcmp(p.reference,"")==0){
		  gtk_widget_show (labelRef);
b=0;
}
else {
		  gtk_widget_hide(labelRef);
}
if(strcmp(p.etage,"")==0){
		  gtk_widget_show (labelEtage);
b=0;
}
else {
		  gtk_widget_hide(labelEtage);
}
if(strcmp(p.valeur,"")==0){
		  gtk_widget_show (labelValeur);
b=0;
}
else {
		  gtk_widget_hide(labelValeur);
}
if(strcmp(p.jour,"")==0){
		  gtk_widget_show (labelJour);
b=0;
}
else {
		  gtk_widget_hide(labelJour);
}
if(strcmp(p.heure,"")==0){
		  gtk_widget_show (labelHeure);
b=0;
}
else {
		  gtk_widget_hide(labelHeure);
}


if(b==1){  
                if(exist_capteur(p.reference)==1)
        {
		modifiercapteur(p,ver);

				  gtk_widget_show (success);
				gtk_widget_hide (existe);
        }
        else {
						  gtk_widget_hide (success);

						  gtk_widget_show (existe);
        }

        }
}


void
on_validermodification_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonhomemodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget * home;
	 
   	home = create_menuPrinahmed ();
    gtk_widget_show (home);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "modfCapt");
    gtk_widget_destroy(captHome);
}


void
on_buttonrechercher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonhomeconsult_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget * home;
	home = create_menuPrinahmed ();
    gtk_widget_show (home);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "gestCapt");
    gtk_widget_destroy(captHome);

}


void
on_buttonquitterconsult_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

    GtkWidget *captHome;
    captHome = lookup_widget(button, "gestCapt");
    gtk_widget_destroy(captHome);
}


void
on_buttonajouterconsult_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * ajout;
	 
   	ajout = create_ajtCapt ();
    gtk_widget_show (ajout);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "gestCapt");
    gtk_widget_destroy(captHome);
}


void
on_buttonmodifierconsult_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * modf;
	 
   	modf = create_modfCapt ();
    gtk_widget_show (modf);
    GtkWidget *captHome;
    captHome = lookup_widget(button, "gestCapt");
    gtk_widget_destroy(captHome);
}


void
on_supprimer_afficher_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget* treeview;
	GtkWidget* afficher;
	GtkWidget* gerer;
	gerer=lookup_widget(objet,"gestCapt");
	gtk_widget_destroy(gerer);
	afficher=lookup_widget(objet,"affichageahmed");
	afficher=create_affichageahmed();
	gtk_widget_show(afficher);
	treeview=lookup_widget(afficher,"treeviewconsult");
	afficher_capteur(treeview);
	
}


void
on_treeviewconsult_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *reference;
        gchar *type;
        gchar *etage;
        gchar *valeur;
	gchar *jour;
	gchar *heure;
	capt k;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &reference, 1, &type, 2, &etage, 3, &valeur, 4, &jour, 5, &heure, -1);
		strcpy(k.reference,reference);
		strcpy(k.type,type);
		strcpy(k.etage,etage);
		strcpy(k.valeur,valeur);
		strcpy(k.jour,jour);
		strcpy(k.heure,heure);
		
		///////appele fonction suprrimer 
		///supprimer_capteur(c);
		
		afficher_capteur(treeview);
}
}


void
on_supprimercapteur_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        gchar *reference;
	gchar*type;
gchar*valeur;
gchar*etage ;
gchar*jour;
gchar*heure;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
     
        p=lookup_widget(button,"treeviewconsult");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
         if(gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
         {gtk_tree_model_get (model,&iter,0,&reference,1,&type,2,&etage,3,&valeur,4,&jour,5,&heure,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimercapteur(reference);// supprimer la ligne du fichier
}
}

void
on_HOME_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget * home;
		 
	home = create_menuPrinahmed ();
	gtk_widget_show (home);
	GtkWidget *captHome;
	captHome = lookup_widget(button, "affichageahmed");
	gtk_widget_destroy(captHome);
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelid;
GtkWidget *nbResultat;
GtkWidget *message;
char id[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entry10");
labelid=lookup_widget(button,"label47");
p1=lookup_widget(button,"treeviewconsult");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(id,"")==0){
  gtk_widget_show (labelid);b=0;
}else{
b=1;
gtk_widget_hide (labelid);}

if(b==0){return;}else{

nb=ChercherCapteur(p1,"Capteur.txt",id);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(button,"label50");
message=lookup_widget(button,"label49");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}
}



