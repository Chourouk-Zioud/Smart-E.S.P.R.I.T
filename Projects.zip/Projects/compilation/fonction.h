#ifndef FONCTIONS_H_
#define FONCTIONS_H_
int sommer(int a, int b);
int soustraire(int a, int b);
float diviser(int a, int b);
#endif
