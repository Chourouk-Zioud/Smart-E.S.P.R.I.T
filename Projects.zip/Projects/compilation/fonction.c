#include <stdio.h>
#include "fonction.h"
int sommer(int a, int b) {
return (a + b);
}
int soustraire(int a, int b) {
return (a - b);
}
float diviser(int a, int b) {
return ((float) a / b);
}
