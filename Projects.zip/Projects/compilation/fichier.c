#include <stdio.h>
int main()
{
int x = 0;
printf("x = ");
scanf("%d", x);
return (0);
}
