void sayHello(char nom[],char hello[]);
