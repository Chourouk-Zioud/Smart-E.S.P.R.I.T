#include <gtk/gtk.h>


void
on_bouton_connecter_kais_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_calendar_aujourdhui_kais_day_selected
                                        (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_bouton_appeler_kais_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_envoyer_sms_kais_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_envoyer_mail_kais_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_afficher_kais_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_ajouter_kais_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_modifier_kais_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_supprimer_kais_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_poste_plus_occupe_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radio_ajouter_homme_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radio_ajouter_femme_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_calendar_ajouter_ddn_kais_day_selected
                                        (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_check_ajouter_etudiant_kais_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_ajouter_stock_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_ajouter_restaurant_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_ajouter_nutritionniste_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_ajouter_foyer_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_ajouter_technicien_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bouton_confirmer_ajout_kais_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_annuler_ajout_kais_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_quitter_recherche_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_verifier_recherche_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radio_modifier_femme_kais_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radio_modifier_homme_kais_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bouton_confirmer_modification_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_annuler_modification_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_utilisateurs_kais_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bouton_actualiser_utilisateurs_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_annuler_suppression_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_confirmer_suppression_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button_modifier_check_kais_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_bouton_about_kais_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bouton_quitter_utilisateurs_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

