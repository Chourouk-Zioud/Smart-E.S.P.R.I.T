#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "admin.h"

////////////////////////// VARIABLES GENERALES //////////////////////////

int sexe_ajout = 1;
int sexe_modifier = 1;
int choix[6]={0,0,0,0,0,0};
int checked;

////////////////////////// AUTHENTIFICATION //////////////////////////

void
on_bouton_connecter_kais_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *login;
	GtkWidget *password;
	GtkWidget *gestion_des_utilisateurs;
	GtkWidget *authentification;
	char user[20];
	char pass[20];
	int trouve;

	login = lookup_widget (objet, "entry_login_kais");
	strcpy(user, gtk_entry_get_text(GTK_ENTRY(login)));

	password = lookup_widget (objet, "entry_password_kais");
	strcpy(pass, gtk_entry_get_text(GTK_ENTRY(password)));

	trouve=verif_admin(user,pass);

	if(trouve==1)
	{
		authentification = lookup_widget(objet,"authentification");
		gestion_des_utilisateurs = create_gestion_des_utilisateurs();
		gtk_widget_show (gestion_des_utilisateurs);
		gtk_widget_hide(authentification);
	}
}

////////////////////////// ACCEUIL //////////////////////////

             /**************** date du jour ****************/
/*
void
on_calendar_aujourdhui_kais_day_selected
                                        (GtkCalendar     *calendar,
                                        gpointer         user_data)
{
	GtkWidget *gestion_des_utilisateurs;
	GtkWidget *CALENDAR;

	CALENDAR = lookup_widget(calendar,"calendar_aujourdhui_kais");
	gtk_calendar_new(CALENDAR);
 
}



             **************** appeler l'admin ****************
void
on_bouton_appeler_kais_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{

}

             **************** envoyer sms au admin ****************
void
on_bouton_envoyer_sms_kais_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{

}

             **************** envoyer mail au admin ****************
void
on_bouton_envoyer_mail_kais_clicked    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	mailto:contact@esprit.tn
}

*/
             /**************** goto treeview ****************/
void
on_bouton_afficher_kais_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *afficher_utilisateurs;
	GtkWidget *treeview_utilisateurs_kais;

	afficher_utilisateurs = lookup_widget(objet,"afficher_utilisateurs");
	afficher_utilisateurs = create_afficher_utilisateurs();
	gtk_widget_show(afficher_utilisateurs);
	treeview_utilisateurs_kais = lookup_widget(afficher_utilisateurs,"treeview_utilisateurs_kais");
	afficher_utl(treeview_utilisateurs_kais,"BD.txt");

}

             /**************** goto formulaire d'ajout ****************/
void
on_bouton_ajouter_kais_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ajouter_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	ajouter_utilisateur = lookup_widget(objet,"ajouter_utilisateur");
	ajouter_utilisateur = create_ajouter_utilisateur();
	gtk_widget_show(ajouter_utilisateur);
}

             /**************** goto formulaire de modification ****************/
void
on_bouton_modifier_kais_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *modifier_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	modifier_utilisateur = lookup_widget(objet,"modifier_utilisateur");
	modifier_utilisateur = create_modifier_utilisateur();
	gtk_widget_show(modifier_utilisateur);
}

             /**************** goto formulaire de suppression ****************/
void
on_bouton_supprimer_kais_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *supprimer_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs =lookup_widget(objet,"gestion_des_utilisateurs");
	supprimer_utilisateur = lookup_widget(objet,"supprimer_utilisateur");
	supprimer_utilisateur = create_supprimer_utilisateur();
	gtk_widget_show(supprimer_utilisateur);
}

             /**************** afficher le poste le plus accupé ****************/
void
on_bouton_poste_plus_occupe_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *pInfo;
	char poste[1000],str[1000];

	strcpy(poste,plus_occupe("BD.txt"));
	sprintf(str,"%s",poste);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}

////////////////////////// RADIO BUTTON AJOUT SEXE //////////////////////////

void
on_radio_ajouter_homme_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(togglebutton))
		{sexe_ajout=1;}
}


void
on_radio_ajouter_femme_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if ( gtk_toggle_button_get_active(togglebutton))
		{sexe_ajout=2;}
}


////////////////////////// CHECK BUTTON //////////////////////////

             /**************** etudiant ****************/
void
on_check_ajouter_etudiant_kais_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[0]=1;}
}

             /**************** nutritionniste ****************/
void
on_check_ajouter_nutritionniste_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[1]=1;}
}

             /**************** technicien ****************/
void
on_check_ajouter_technicien_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[2]=1;}
}

             /**************** agent_de_stock ****************/
void
on_check_ajouter_stock_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[3]=1;}
}

             /**************** agent_de_restaurant ****************/
void
on_check_ajouter_restaurant_kais_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[4]=1;}
}

             /**************** agent_de_foyer ****************/
void
on_check_ajouter_foyer_kais_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton))
		{choix[5]=1;}
}

////////////////////////// AJOUTER UTILISATEUR //////////////////////////

void
on_bouton_confirmer_ajout_kais_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *ajouter_utilisateur;
	GtkWidget *gestion_des_utilisateurs;
	GtkWidget *nom;
	GtkWidget *prenom;
	GtkWidget *cin;
	GtkWidget *identifiant;
	GtkWidget *jour;
	GtkWidget *mois;
	GtkWidget *annee;
	GtkWidget *tel;
	GtkWidget *CALENDAR;
	char x[20],y[20],z[20];
	int aa,mm,jj;
	UTL u;

	nom = lookup_widget(objet,"entry_ajouter_nom_kais");
	strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"entry_ajouter_prenom_kais");
	strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	cin = lookup_widget(objet,"entry_ajouter_cin_kais");
	strcpy(x,gtk_entry_get_text(GTK_ENTRY(cin)));
	u.cin = atoi(x);

	identifiant = lookup_widget(objet,"entry_ajouter_id_kais");
	strcpy(y,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	u.identifiant = atoi(y);

	CALENDAR = lookup_widget(objet,"calendar_ajouter_ddn_kais");
	gtk_calendar_get_date (GTK_CALENDAR(CALENDAR), &aa, &mm, &jj);

	u.date_de_naissance.jour = jj;
	u.date_de_naissance.mois = mm+1;
	u.date_de_naissance.annee = aa;

	tel =lookup_widget(objet,"entry_ajouter_tel_kais");
	strcpy(z,gtk_entry_get_text(GTK_ENTRY(tel)));
	u.tel=atoi(z);
	
	if(sexe_ajout==1)
	{strcpy(u.sexe,"homme");
	sexe_ajout=0;
	}
	else
	if(sexe_ajout==2)
	{
	strcpy(u.sexe,"femme");
	sexe_ajout=0;
	}
	

	if(choix[0]==1 && choix[1]==0 && choix[2]==0 && choix[3]==0 && choix[4]==0 && choix[5]==0)
	strcpy(u.poste,"etudiant");

	if(choix[0]==0 && choix[1]==1 && choix[2]==0 && choix[3]==0 && choix[4]==0 && choix[5]==0)
	strcpy(u.poste,"nutritionniste");

	if(choix[0]==0 && choix[1]==0 && choix[2]==1 && choix[3]==0 && choix[4]==0 && choix[5]==0)
	strcpy(u.poste,"technicien");

	if(choix[0]==0 && choix[1]==0 && choix[2]==0 && choix[3]==1 && choix[4]==0 && choix[5]==0)
	strcpy(u.poste,"agent_de_stock");

	if(choix[0]==0 && choix[1]==0 && choix[2]==0 && choix[3]==0 && choix[4]==1 && choix[5]==0)
	strcpy(u.poste,"agent_de_restaurant");

	if(choix[0]==0 && choix[1]==0 && choix[2]==0 && choix[3]==0 && choix[4]==0 && choix[5]==1)
	strcpy(u.poste,"agent_de_foyer");

	ajouter_utl(u,"BD.txt");
}

////////////////////////// ANNULER L'AJOUT //////////////////////////

void
on_bouton_annuler_ajout_kais_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ajouter_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	ajouter_utilisateur = lookup_widget(objet,"ajouter_utilisateur");
	gtk_widget_hide(ajouter_utilisateur);
}

////////////////////////// ANNULER LA RECHERCHE //////////////////////////

void
on_bouton_quitter_recherche_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *rechercher_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	rechercher_utilisateur = lookup_widget(objet,"rechercher_utilisateur");
	gtk_widget_hide(rechercher_utilisateur);
}

////////////////////////// RECHERCHER //////////////////////////

void
on_bouton_verifier_recherche_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int trouve;
	char x[20],msg[1000],ddn[20];
	GtkWidget *rechercher_utilisateur;
	GtkWidget *modifier_utilisateur;
	GtkWidget *identifiant;
	GtkWidget *pInfo;
	UTL u;
	UTL p;

	identifiant = lookup_widget(objet,"entry_recherche_kais");
	strcpy(x,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	u.identifiant=atoi(x);

	p = retourner_utl(u.identifiant,"BD.txt");

	sprintf(ddn,"%d/%d/%d",p.date_de_naissance.jour,p.date_de_naissance.mois,p.date_de_naissance.annee);

	trouve = rechercher_utl(u.identifiant,"BD.txt");
	if(trouve==0)
	{
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,"Identifiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	else
	{


	sprintf(msg,"nom: %s\nprenom: %s\ncin: %d\nid: %d\nné(e) le: %s\nsexe: %s\nposte: %s\nN°tel: %d",p.nom,p.prenom,p.cin,p.identifiant,ddn,p.sexe,p.poste,p.tel);

	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,msg);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}

////////////////////////// RADIO BUTTON MODIFIER SEXE //////////////////////////

void
on_radio_modifier_femme_kais_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
		{sexe_modifier=1;}
}


void
on_radio_modifier_homme_kais_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(togglebutton))
		{sexe_modifier=2;}
}

////////////////////////// MODIFIER UTILISATEUR //////////////////////////

void
on_bouton_confirmer_modification_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ajouter_utilisateur;
	GtkWidget *gestion_des_utilisateurs;
	GtkWidget *nom;
	GtkWidget *prenom;
	GtkWidget *cin;
	GtkWidget *identifiant;
	GtkWidget *sexe_h;
	GtkWidget *sexe_f;
	GtkWidget *ddn_jour;
	GtkWidget *ddn_mois;
	GtkWidget *ddn_annee;
	GtkWidget *poste;
	GtkWidget *tel;
	GtkWidget *combobox_modifier_poste_kais;
	GtkWidget *pInfo;
	int trouve,aa,mm,jj;
	int aux=-1;
	bool bh,bf;
	char x[20],y[20],z[20],id[20],c[20],t[20];
	UTL u;

	if(checked=1)
	{
	nom = lookup_widget(objet,"entry_modifier_nom_kais");
	strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"entry_modifier_prenom_kais");
	strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	cin = lookup_widget(objet,"entry_modifier_cin_kais");
	strcpy(x,gtk_entry_get_text(GTK_ENTRY(cin)));
	u.cin = atoi(x);

	identifiant = lookup_widget(objet,"entry_modifier_id_kais");
	strcpy(y,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	u.identifiant = atoi(y);

	ddn_jour = lookup_widget(objet,"spin_modifier_jour_kais");
	u.date_de_naissance.jour = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (ddn_jour));

	ddn_mois = lookup_widget(objet,"spin_modifier_mois_kais");
	u.date_de_naissance.mois = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (ddn_mois));

	ddn_annee = lookup_widget(objet,"spin_modifier_annee_kais");
	u.date_de_naissance.annee = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (ddn_annee));

	if(sexe_modifier==1)
	{strcpy(u.sexe,"homme");
	sexe_modifier=0;}
	else
	if(sexe_modifier==2)
	{strcpy(u.sexe,"femme");
	sexe_modifier=0;}

	poste = lookup_widget(objet,"combobox_modifier_poste_kais");
	strcpy(u.poste,gtk_combo_box_get_active_text(GTK_COMBO_BOX(poste)));

	tel = lookup_widget(objet,"entry_modifier_tel_kais");
	strcpy(z,gtk_entry_get_text(GTK_ENTRY(tel)));
	u.tel=atoi(z);

	modifier_utl(u,"BD.txt");
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Utilisateur modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	else
	{
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Attention !!! Utilisateur n'existe pas !!!");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	checked=0;
}

////////////////////////// ANNULER MODIFICATION //////////////////////////

void
on_bouton_annuler_modification_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *modifier_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	modifier_utilisateur = lookup_widget(objet,"modifier_utilisateur");
	gtk_widget_hide(modifier_utilisateur);
}

//////////////////////////  TREEVIEW  //////////////////////////

void
on_treeview_utilisateurs_kais_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *nom;
	gchar *prenom;
	gchar *cin;
	gchar *identifiant;
	gchar *date ;
	gchar *sexe;
	gchar *poste;
	gchar *tel;
	GtkWidget *pInfo;
	int id;
	UTL u;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&cin,3,&identifiant,4,&date,5,&sexe,6,&poste,7,&tel,-1);
	//afficher_utl(treeview,"BD.txt");

	id=atoi(identifiant);

	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cet utilisateur ?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	{gtk_widget_destroy(pInfo);
	supprimer_treeview(id,"BD.txt");
	break;}
	case GTK_RESPONSE_NO:
	{gtk_widget_destroy(pInfo);
	break;}
	}
	}
}

//////////////////////////  ACTUALISER  //////////////////////////

void
on_bouton_actualiser_utilisateurs_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview_utilisateurs_kais;
	GtkWidget *afficher_utilisateurs;

	afficher_utilisateurs = lookup_widget(objet,"afficher_utilisateurs");
	gtk_widget_destroy(afficher_utilisateurs);
	afficher_utilisateurs = lookup_widget(objet,"afficher_utilisateurs");
	afficher_utilisateurs = create_afficher_utilisateurs();
	gtk_widget_show(afficher_utilisateurs);
	treeview_utilisateurs_kais = lookup_widget(afficher_utilisateurs,"treeview_utilisateurs_kais");
	afficher_utl(treeview_utilisateurs_kais,"BD.txt");

}

//////////////////////////  QUITTER TREEVIEW  //////////////////////////

void
on_bouton_quitter_utilisateurs_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *afficher_utilisateurs;
	GtkWidget *gestion_des_utilisateurs;

	afficher_utilisateurs = lookup_widget(objet,"afficher_utilisateurs");
	gtk_widget_destroy(afficher_utilisateurs);

}

////////////////////////// ANNULER SUPPRESSION //////////////////////////

void
on_bouton_annuler_suppression_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *supprimer_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	supprimer_utilisateur = lookup_widget(objet,"supprimer_utilisateur");
	gtk_widget_hide(supprimer_utilisateur);
}

////////////////////////// SUPPRESSION //////////////////////////

void
on_bouton_confirmer_suppression_kais_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *gestion_des_utilisateurs;
	GtkWidget *supprimer_utilisateur;
	GtkWidget *identifiant;
	GtkWidget *pInfo;
	UTL u;
	int trouve,id;
	char ident[20];

	identifiant = lookup_widget(objet,"entry_supprimer_id_kais");
	strcpy(ident,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	id = atoi(ident);
	trouve = rechercher_utl(id,"BD.txt");

	if(trouve==1)
	{
		u = retourner_utl(id,"BD.txt");
		supprimer_utl(u,"BD.txt");
		gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
		supprimer_utilisateur = lookup_widget(objet,"supprimer_utilisateur");
		gtk_widget_hide(supprimer_utilisateur);
	}
	else
	{
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Utilisateur n'existe pas !!!\nentrer un autre identifiant");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}

////////////////////////// CHECK //////////////////////////

void
on_button_modifier_check_kais_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *ID;
	GtkWidget *nom;
	GtkWidget *prenom;
	GtkWidget *cin;
	GtkWidget *identifiant;
	GtkWidget *sexe_h;
	GtkWidget *sexe_f;
	GtkWidget *ddn_jour;
	GtkWidget *ddn_mois;
	GtkWidget *ddn_annee;
	GtkWidget *poste;
	GtkWidget *tel;
	GtkWidget *pInfo;
	int aux,aa,mm,jj,i;
	int trouve=0;
	bool bh,bf;
	char ident[20],x[20],y[20],z[20],id[20],c[20],t[20];
	UTL p;


	ID = lookup_widget(objet,"entry_modifier_check_kais");
	strcpy(ident,gtk_entry_get_text(GTK_ENTRY(ID)));
	i = atoi(ident);

	trouve = rechercher_utl(i,"BD.txt");
	p = retourner_utl(i,"BD.txt");

	if(trouve==1){
	checked=1;
	nom = lookup_widget(objet,"entry_modifier_nom_kais");
	gtk_entry_set_text(GTK_ENTRY(nom),p.nom);

	prenom = lookup_widget(objet,"entry_modifier_prenom_kais");
	gtk_entry_set_text(GTK_ENTRY(prenom),p.prenom);

	cin = lookup_widget(objet,"entry_modifier_cin_kais");
	sprintf(c,"%d",p.cin);
	gtk_entry_set_text(GTK_ENTRY(cin),c);

	identifiant = lookup_widget(objet,"entry_modifier_id_kais");
	sprintf(id,"%d",p.identifiant);
	gtk_entry_set_text(GTK_ENTRY(identifiant),id);

	sexe_h = lookup_widget(objet,"radio_modifier_homme_kais");
	if(strcmp(p.sexe,"homme")==0)
	bh=TRUE;
	else
	bh=FALSE;
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (sexe_h),bh);

	sexe_f = lookup_widget(objet,"radio_modifier_femme_kais");
	if(strcmp(p.sexe,"femme")==0)
	bf=TRUE;
	else
	bf=FALSE;
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (sexe_f),bf);



	ddn_jour = lookup_widget(objet,"spin_modifier_jour_kais");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (ddn_jour),p.date_de_naissance.jour);

	ddn_mois = lookup_widget(objet,"spin_modifier_mois_kais");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (ddn_mois),p.date_de_naissance.mois);

	ddn_annee = lookup_widget(objet,"spin_modifier_annee_kais");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (ddn_mois),p.date_de_naissance.annee);

	poste = lookup_widget(objet,"combobox_modifier_poste_kais");
	if(strcmp(p.poste,"etudiant")==0)
	aux=0;
	if(strcmp(p.poste,"nutritionniste")==0)
	aux=1;
	if(strcmp(p.poste,"technicien")==0)
	aux=2;
	if(strcmp(p.poste,"agent_de_stock")==0)
	aux=3;
	if(strcmp(p.poste,"agent_de_restaurant")==0)
	aux=4;
	if(strcmp(p.poste,"agent_de_foyer")==0)
	aux=5;
	gtk_combo_box_set_active(GTK_COMBO_BOX(poste),aux);

	tel = lookup_widget(objet,"entry_modifier_tel_kais");
	sprintf(t,"%d",p.tel);
	gtk_entry_set_text(GTK_ENTRY(tel),t);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Utilisateur trouvé !!!");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	else{
	checked=0;
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Utilisateur non trouvé !!!");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
}

////////////////////////// INFOS //////////////////////////

void
on_bouton_about_kais_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *rechercher_utilisateur;
	GtkWidget *gestion_des_utilisateurs;

	gestion_des_utilisateurs = lookup_widget(objet,"gestion_des_utilisateurs");
	rechercher_utilisateur = lookup_widget(objet,"rechercher_utilisateur");
	rechercher_utilisateur = create_rechercher_utilisateur();
	gtk_widget_show(rechercher_utilisateur);
}


