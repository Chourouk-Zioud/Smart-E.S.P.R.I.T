#include <gtk/gtk.h>

void
on_button1_gestion_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_meilleur_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_home_ab_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_ajouter_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_modifier_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_supprimer_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_afficher_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_home_ab_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_ajouter_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button9_return_ab_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_modifier_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_semaine1_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_semaine2_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_semaine4_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_semaine3_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button14_rechercher_ab_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button16_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_petitdej_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_dejeuner_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_diner_ab_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button18_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button17_supprimer_ab_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_meilleur_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton4_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
