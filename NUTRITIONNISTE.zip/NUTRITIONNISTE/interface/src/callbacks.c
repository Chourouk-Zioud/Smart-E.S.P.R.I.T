#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "menu.h"

int p;
char x[20];
char x1[20];
char x2[20];
char x3[20];

void
on_button1_gestion_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *treeview1_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_button2_meilleur_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Meilleur1_ab;
Meilleur1_ab=lookup_widget(button,"Meilleur1_ab");
Meilleur1_ab=create_Meilleur1_ab();
gtk_widget_show(Meilleur1_ab);
}


void
on_button7_home_ab_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Gestion_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
gtk_widget_destroy(Gestion_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_button3_ajouter_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_ab;
GtkWidget *Gestion_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
gtk_widget_destroy(Gestion_ab);
Ajouter_ab=lookup_widget(button,"Ajouter_ab");
Ajouter_ab=create_Ajouter_ab();
gtk_widget_show(Ajouter_ab);
}


void
on_button4_modifier_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Modifier_ab;
GtkWidget *Gestion_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
gtk_widget_destroy(Gestion_ab);
Modifier_ab=lookup_widget(button,"Modifier_ab");
Modifier_ab=create_Modifier_ab();
gtk_widget_show(Modifier_ab);
}


void
on_button5_supprimer_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Supprimer_ab;
GtkWidget *Gestion_ab;
GtkWidget *treeview3_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
gtk_widget_destroy(Gestion_ab);
Supprimer_ab=lookup_widget(button,"Supprimer_ab");
Supprimer_ab=create_Supprimer_ab();
gtk_widget_show(Supprimer_ab);
treeview3_ab=lookup_widget(Gestion_ab,"treeview3_ab");
afficher_menu(treeview3_ab);
}


void
on_button6_afficher_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Afficher_ab;
GtkWidget *treeview2_ab;
Gestion_ab=lookup_widget(button,"Gestion_ab");
gtk_widget_destroy(Gestion_ab);
Afficher_ab=lookup_widget(button,"Afficher_ab");
Afficher_ab=create_Afficher_ab();
gtk_widget_show(Afficher_ab);
treeview2_ab=lookup_widget(Afficher_ab,"treeview2_ab");
afficher_menu(treeview2_ab);
}


void
on_button8_home_ab_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Ajouter_ab;
Ajouter_ab=lookup_widget(button,"Ajouter_ab");
gtk_widget_destroy(Ajouter_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_button10_ajouter_ab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entree,*plat, *combobox,*dessert;
Menus menu;
entree = lookup_widget (button, "entry1_entree_ab");
plat= lookup_widget (button, "entry2_plat_ab"); 
dessert= lookup_widget (button, "entry3_dessert_ab");
combobox = lookup_widget (button, "comboboxentry1_ab");
 
strcpy(menu.entree , gtk_entry_get_text(GTK_ENTRY(entree)));
strcpy(menu.plat , gtk_entry_get_text(GTK_ENTRY(plat)));
strcpy(menu.dessert, gtk_entry_get_text(GTK_ENTRY(dessert)));
if (strcmp("Lundi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=1;
if (strcmp("Mardi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=2;
if (strcmp("Mercredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=3;
if (strcmp("Jeudi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=4;
if (strcmp("Vendredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=5;
if (strcmp("Samedi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=6;
if (strcmp("Dimanche",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
menu.jours=7;
menu.type=p;
ajouter_ab(menu);
}


void
on_radiobutton1_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=1;
}


void
on_radiobutton2_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=2;
}


void
on_radiobutton3_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=3;
}


void
on_button9_return_ab_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Ajouter_ab;
GtkWidget *treeview1_ab;
Ajouter_ab=lookup_widget(button,"Ajouter_ab");
gtk_widget_destroy(Ajouter_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_button11_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Modifier_ab;
Modifier_ab=lookup_widget(button,"Modifier_ab");
gtk_widget_destroy(Modifier_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_button13_modifier_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entree,*plat, *combobox,*dessert;
Menus new;
entree = lookup_widget (button, "entry4_entree_ab");
plat = lookup_widget (button, "entry5_plat_ab"); 
dessert= lookup_widget (button, "entry6_dessert_ab");
combobox = lookup_widget (button, "comboboxentry2_ab");
 
strcpy(new.entree , gtk_entry_get_text(GTK_ENTRY(entree)));
strcpy(new.plat, gtk_entry_get_text(GTK_ENTRY(plat)));
strcpy(new.dessert , gtk_entry_get_text(GTK_ENTRY(dessert)));
if (strcmp("Lundi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=1;
if (strcmp("Mardi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=2;
if (strcmp("Mercredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=3;
if (strcmp("Jeudi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=4;
if (strcmp("Vendredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=5;
if (strcmp("Samedi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=6;
if (strcmp("Dimanche",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
new.jours=7;
new.type=p;
modifier_ab(new);
}


void
on_button12_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Modifier_ab;
GtkWidget *treeview1_ab;
Modifier_ab=lookup_widget(button,"Modifier_ab");
gtk_widget_destroy(Modifier_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_button15_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Afficher_ab;
Afficher_ab=lookup_widget(button,"Afficher_ab");
gtk_widget_destroy(Afficher_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_checkbutton1_semaine1_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
x[0]="1";
}


void
on_checkbutton2_semaine2_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
x[1]="2";
}


void
on_checkbutton4_semaine4_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
x[3]="4";
}


void
on_checkbutton3_semaine3_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
x[2]="3";
}


void
on_button14_rechercher_ab_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *c;
GtkWidget *Recherche_ab,*w1;
GtkWidget *treeview5_ab;
char ce[20];
char xe1[20];
char xe2[20];
char xe3[20];
strcpy(xe1,x1);
strcpy(xe2,x2);
strcpy(xe3,x3);
c = lookup_widget (button, "entry1_ab");
Recherche_ab=lookup_widget(button,"button14_rechercher_ab");
Recherche_ab=create_Recherche_ab();
gtk_widget_show(Recherche_ab);
strcpy(ce , gtk_entry_get_text(GTK_ENTRY(c)));

treeview5_ab=lookup_widget(Recherche_ab,"treeview5_ab");

rechercher_menu(treeview5_ab,xe1,xe2,xe3,ce);
}


void
on_button16_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Afficher_ab;
GtkWidget *treeview1_ab;
Afficher_ab=lookup_widget(button,"Afficher_ab");
gtk_widget_destroy(Afficher_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_checkbutton1_petitdej_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
p=1;
}


void
on_checkbutton2_dejeuner_ab_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
p=2;
}


void
on_checkbutton3_diner_ab_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
p=3;
}


void
on_button18_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Supprimer_ab;
Supprimer_ab=lookup_widget(button,"Supprimer_ab");
gtk_widget_destroy(Supprimer_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_button17_supprimer_ab_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *combobox;
Menus R;

combobox = lookup_widget (button, "comboboxentry3_ab");
 

if (strcmp("Lundi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=1;
if (strcmp("Mardi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=2;
if (strcmp("Mercredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=3;
if (strcmp("Jeudi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=4;
if (strcmp("Vendredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=5;
if (strcmp("Samedi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=6;
if (strcmp("Dimanche",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)))==0)
R.jours=7;
R.type=p;
supprimer_ab(R);

}


void
on_button19_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Supprimer_ab;
GtkWidget *treeview1_ab;
Supprimer_ab=lookup_widget(button,"Supprimer_ab");
gtk_widget_destroy(Supprimer_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_button21_home_ab_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil_ab;
GtkWidget *Meilleur_ab;
Meilleur_ab=lookup_widget(button,"Meilleur_ab");
gtk_widget_destroy(Meilleur_ab);
Acceuil_ab=lookup_widget(button,"Acceuil_ab");
Acceuil_ab=create_Acceuil_ab();
gtk_widget_show(Acceuil_ab);
}


void
on_button20_meilleur_ab_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Meilleur2_ab,*w1,*spinbutton1_ab;
GtkWidget *treeview4_ab;

int c;

Meilleur2_ab=lookup_widget(button,"Meilleur2_ab");
Meilleur2_ab=create_Meilleur2_ab();
gtk_widget_show(Meilleur2_ab);
spinbutton1_ab=lookup_widget(button,"spinbutton1_ab");
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1_ab));
treeview4_ab=lookup_widget(Meilleur2_ab,"treeview4_ab");

afficher_Dash(treeview4_ab,c);
}


void
on_button22_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Meilleur_ab;
GtkWidget *treeview1_ab;
Meilleur_ab=lookup_widget(button,"Meilleur_ab");
gtk_widget_destroy(Meilleur_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_button23_return_ab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Gestion_ab;
GtkWidget *Recherche_ab;
GtkWidget *treeview1_ab;
Recherche_ab=lookup_widget(button,"Recherche_ab");
gtk_widget_destroy(Recherche_ab);
Gestion_ab=lookup_widget(button,"Gestion_ab");
Gestion_ab=create_Gestion_ab();
gtk_widget_show(Gestion_ab);
treeview1_ab=lookup_widget(Gestion_ab,"treeview1_ab");
afficher_menu(treeview1_ab);
}


void
on_radiobutton4_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=1;
}


void
on_radiobutton5_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=2;
}


void
on_radiobutton6_ab_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
p=3;
}

