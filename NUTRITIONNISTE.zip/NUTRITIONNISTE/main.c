#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"


void main() {
    int init=1;
    char commande[20]; 
    int p;
    Menus menu;
    while (init==1){
        printf("donner votre commande:\n");
        scanf("%s",commande);
        
        if (strcmp(commande,"afficher")==0)
            afficher(menu);
        else if (strcmp(commande,"ajouter")==0){
             printf("jour de la semaine:\n");
    scanf("%d",&menu.jours);
    printf("Petit Dejeuner:1|Dejeuner:2|Diner:3\n");
    scanf("%d",&menu.type);
    printf("Entrée\n");
    scanf("%s",menu.entree);
    
    printf("Plat principal\n");
    
    scanf("%s",menu.plat);
    
    printf("Dessert:\n");
    scanf("%s",menu.dessert);
            ajouter(menu);}
        else if (strcmp(commande,"rechercher")==0){
            p=rechercher(menu);
            printf("%d",p);}
        else if (strcmp(commande,"modi
fier")==0)
            modifier(menu);
        else if (strcmp(commande,"supprimer")==0)
            supprimer(menu);
        else if (strcmp(commande,"meilleur")==0)
            Meilleur(menu);   
        printf("voulez-vous saisir une nouvelle commande? 1|0\n");
        scanf("%d", &init);

    }

}
