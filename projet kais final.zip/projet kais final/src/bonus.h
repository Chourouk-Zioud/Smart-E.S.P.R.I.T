
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>


/////////////////////////// STRUCT EP ///////////////////////////

typedef struct etage_panne{
	int jour;
	int heure;
	int etage;
	float debit;
}ETP;

/////////////////////////// FONCTIONS ///////////////////////////

void etage_panne(char *fname);

void supprimer_panne(ETP ep,char *fname);

void afficher_EP(GtkWidget *liste,char *fname);









