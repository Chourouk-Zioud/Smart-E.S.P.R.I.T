#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "stock.h"

int p=1;
/////////////////////////////////////////////////////////
void
on_button1_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_home;
	fenetre_home = create_Home_ME();

	fenetre_ajout = lookup_widget(objet, "AJOUTER");

	fenetre_ajout = create_AJOUTER();
	gtk_widget_show(fenetre_ajout);
	gtk_widget_hide(fenetre_home);
	
}
/////////////////////////////////////////////////////////

void
on_button2_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_modifier,*fenetre_home;
	fenetre_home = create_Home_ME();
	
	fenetre_modifier = lookup_widget(objet, "MODIFIER");
	fenetre_modifier = create_MODIFIER();
	gtk_widget_show(fenetre_modifier);
	gtk_widget_hide(fenetre_home);
}
/////////////////////////////////////////////////////////

void
on_button3_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_supprimer,*fenetre_home;
	fenetre_home = create_Home_ME();
	fenetre_supprimer = lookup_widget(objet, "SUPPRIMER");
	fenetre_supprimer = create_SUPPRIMER();
	gtk_widget_show(fenetre_supprimer);
	gtk_widget_hide(fenetre_home);
}
/////////////////////////////////////////////////////////?????


void
on_button7_AJ_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_home,*fenetre_ajouter;
	GtkWidget *treeview1;
	

	//fenetre_home = lookup_widget(objet, "Home_ME");
	fenetre_home = create_Home_ME();
	gtk_widget_show(fenetre_home);
	
	treeview1=lookup_widget(objet,"treeview1_ME");
	afficher_stock_tv(treeview1);	
	fenetre_ajouter = lookup_widget(objet, "AJOUTER");
	gtk_widget_hide(fenetre_ajouter);
}


void
on_button8_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *entryref, *entryfour, *entryprix ,*labelsuccess, *quant , *entrydate;
	GtkWidget *combobox1;
	
	char chaine[50];
	
        stk c;
	entryref = lookup_widget(objet, "entry3_reference");
	strcpy(c.ref, gtk_entry_get_text(GTK_ENTRY(entryref)));

	combobox1 = lookup_widget(objet, "combobox1_categorie");
	if (strcmp("Boissons", gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))) == 0){
		strcpy(chaine , "Boissons");
	}
	else if (strcmp("Fruits", gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))) == 0) {
		strcpy(chaine , "Fruits");
	}
	else if (strcmp("Legumes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1))) == 0){
		strcpy(chaine ,"Legumes");
	}
	strcpy(c.categorie, chaine);

	quant = lookup_widget(objet, "spinbutton3");
	c.quantite =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(objet,"spinbutton3")));

	entrydate = lookup_widget(objet, "entry2_date");
	strcpy(c.date ,gtk_entry_get_text(GTK_ENTRY(entrydate)));


	entryfour = lookup_widget(objet, "entry4_fournisseur");
	strcpy(c.fournisseur ,gtk_entry_get_text(GTK_ENTRY(entryfour)));

	entryprix = lookup_widget(objet, "entry5_prix");
	strcpy(c.prix ,gtk_entry_get_text(GTK_ENTRY(entryprix)));

        

	labelsuccess=lookup_widget(objet,"msg_succes");


	ajouter_stock(c);
		gtk_widget_show (labelsuccess);

	
}

////////////////////////////////////////////////////////////////
void
on_button9_MOD_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_home,*fenetre_modifier;
	GtkWidget *treeview2;
	
	
	fenetre_home = lookup_widget(objet, "Home_ME");
	fenetre_home = create_Home_ME();
	gtk_widget_show(fenetre_home);
	treeview2=lookup_widget(objet,"treeview1_ME");
	afficher_stock_tv(treeview2);
	fenetre_modifier = lookup_widget(objet, "MODIFIER");
	gtk_widget_hide(fenetre_modifier);
}


void
on_button10_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *entry_ref, *entryfour, *entryprix, *lab, *entrydate;
	GtkWidget *cal;
	GtkWidget *SB;
	char chaine[50],chaine2[50];
	int jj,mm,aa;
	stk new;
	//sprintf(chaine,"%d",n);
	
	entry_ref = lookup_widget(objet, "entry6_reference");
	strcpy(new.ref, gtk_entry_get_text(GTK_ENTRY(entry_ref)));
	//categorie
	
	if (recherche_stock(new.ref)==0)
		{lab=lookup_widget(objet,"label_msg_erreur");
		gtk_label_set_text(GTK_LABEL(lab), "cette reference n'existe pas");}
	else {
	if (p==1) {strcpy (chaine, "Boissons");  }
	else if(p==2) {strcpy (chaine, "Fruits"); }
	else if(p==3){strcpy (chaine, "Legumes"); }
	strcpy(new.categorie, chaine);	
	SB = lookup_widget(objet,"spinbutton2_ME");
	new.quantite =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(objet,"spinbutton2_ME")));


	/*cal = lookup_widget(objet,"calendar2");
	gtk_calendar_get_date (GTK_CALENDAR(cal),
                       &aa,
                       &mm,
                       &jj);
	sprintf(chaine2,"%d /%d/ %d",jj,mm,aa);
	strcpy(new.date , chaine2);*/

	entrydate = lookup_widget(objet, "entry1_dateexp");
	strcpy(new.date , gtk_entry_get_text(GTK_ENTRY(entrydate)));


	entryfour = lookup_widget(objet, "entry7_fournisseur");
	strcpy(new.fournisseur , gtk_entry_get_text(GTK_ENTRY(entryfour)));
	

	entryprix = lookup_widget(objet, "entry8_prix");
	strcpy(new.prix , gtk_entry_get_text(GTK_ENTRY(entryprix)));
	
	
	modifier_stock(new);
	
	}

}


void
on_button12_supprimer_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *E;
	stk s;
	E=lookup_widget (objet,"entry9_reference");
	strcpy(s.ref, gtk_entry_get_text(GTK_ENTRY(E)));
	supprimer_stock(s.ref);
}


void
on_button13_SUPP_home_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_home,*fenetre_supprimer;
	GtkWidget *treeview3;
	
	fenetre_home = lookup_widget(objet, "Home_ME");
	fenetre_home = create_Home_ME();
	gtk_widget_show(fenetre_home);
	treeview3=lookup_widget(objet,"treeview1_ME");
	afficher_stock_tv(treeview3);
	fenetre_supprimer = lookup_widget(objet, "SUPPRIMER");
	gtk_widget_hide(fenetre_supprimer);
}


void
on_button6_rupstock_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		p=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		p=2;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
		p=3;
}


void
on_button14_RUPST_Khome_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_home,*fenetre;
	
	fenetre = lookup_widget(objet, "rupture_stock");
	gtk_widget_hide(fenetre);
	fenetre_home = lookup_widget(objet, "Home_ME");
	fenetre_home = create_Home_ME();
	gtk_widget_show(fenetre_home);
}




void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_affiche;
	GtkWidget *treeview;
	fenetre_affiche = lookup_widget(button, "AFFICHER");
	fenetre_affiche = create_AFFICHER();
	gtk_widget_show(fenetre_affiche);
	treeview=lookup_widget(fenetre_affiche,"treeview5_ME");
	afficher_stock_tv(treeview);
}


void
on_button1_gestion_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_home;
GtkWidget *treeview1;
fenetre_home = lookup_widget(button, "Home_ME");
fenetre_home = create_Home_ME();
gtk_widget_show(fenetre_home);
treeview1=lookup_widget(fenetre_home,"treeview1_ME");
afficher_stock_tv(treeview1);
}





void
on_button4_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre,*fenetre_rup;
	GtkWidget *treeview4;
	
	fenetre = lookup_widget(objet, "Home_ME");
	fenetre = create_Home_ME();

	gtk_widget_show(fenetre);
	treeview4=lookup_widget(objet,"treeview2_ME");
	afficher_stock_tv(treeview4);

	fenetre_rup = lookup_widget(objet, "rupture_stock");
	gtk_widget_hide(fenetre_rup);
	

	
}


void
on_button2_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *rupture;
GtkWidget *treeview2;
stk c;

rupture = lookup_widget(objet, "rupture_stock");
rupture = create_rupture_stock();
gtk_widget_show(rupture);

rupture_stock(c);

treeview2=lookup_widget(rupture,"treeview2_ME");
afficher_rupt_stock_tv(treeview2);
}

