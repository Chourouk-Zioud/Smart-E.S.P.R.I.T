#include <gtk/gtk.h>


void
on_button1_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_supprimer_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_chercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_AJ_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9_MOD_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button10_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12_supprimer_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button13_SUPP_home_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_rupstock_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button14_RUPST_Khome_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_gestion_clicked             (GtkButton       *button,
                                        gpointer         user_data);


void
on_button4_home_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
